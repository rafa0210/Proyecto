<?
	# Nivel de errores
	error_reporting(E_ALL);
	# Servidor de base de datos
  $dbhost ="localhost";
  # Nombre de la base de datos
  $dbname="test";
  # Usuario de base de datos
  $dbuser="foo";
  # Password de base de datos
  $dbpwd="f";
?>